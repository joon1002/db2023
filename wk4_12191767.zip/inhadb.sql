-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema inha_db
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema inha_db
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `inha_db` DEFAULT CHARACTER SET utf8mb3 ;
USE `inha_db` ;

-- -----------------------------------------------------
-- Table `inha_db`.`building`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `inha_db`.`building` (
  `bid` INT(20) NOT NULL,
  `bname` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`bid`, `bname`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `inha_db`.`room`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `inha_db`.`room` (
  `rid` INT NOT NULL,
  `rname` VARCHAR(45) NOT NULL,
  `capacity` INT NULL,
  `building_bid` INT(20) NOT NULL,
  `building_bname` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`rid`, `rname`, `building_bid`, `building_bname`),
  INDEX `fk_room_building_idx` (`building_bid` ASC, `building_bname` ASC) VISIBLE,
  CONSTRAINT `fk_room_building`
    FOREIGN KEY (`building_bid` , `building_bname`)
    REFERENCES `inha_db`.`building` (`bid` , `bname`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `inha_db`.`department`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `inha_db`.`department` (
  `did` INT NOT NULL,
  `dname` VARCHAR(45) NOT NULL,
  `demail` VARCHAR(45) NULL,
  `dphonenumber` INT(20) NULL,
  `room_rid` INT NOT NULL,
  `room_rname` VARCHAR(45) NOT NULL,
  `room_building_bid` INT(20) NOT NULL,
  `room_building_bname` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`did`, `dname`),
  INDEX `fk_department_room1_idx` (`room_rid` ASC, `room_rname` ASC, `room_building_bid` ASC, `room_building_bname` ASC) VISIBLE,
  CONSTRAINT `fk_department_room1`
    FOREIGN KEY (`room_rid` , `room_rname` , `room_building_bid` , `room_building_bname`)
    REFERENCES `inha_db`.`room` (`rid` , `rname` , `building_bid` , `building_bname`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `inha_db`.`student`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `inha_db`.`student` (
  `sid` INT NOT NULL,
  `sname` VARCHAR(45) NOT NULL,
  `semail` VARCHAR(45) NULL,
  `sphonenumber` VARCHAR(45) NULL,
  `Major` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`sid`, `sname`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `inha_db`.`student_has_department`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `inha_db`.`student_has_department` (
  `student_sid` INT NOT NULL,
  `student_sname` VARCHAR(45) NOT NULL,
  `department_did` INT NOT NULL,
  `department_dname` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`student_sid`, `student_sname`, `department_did`, `department_dname`),
  INDEX `fk_student_has_department_department1_idx` (`department_did` ASC, `department_dname` ASC) VISIBLE,
  INDEX `fk_student_has_department_student1_idx` (`student_sid` ASC, `student_sname` ASC) VISIBLE,
  CONSTRAINT `fk_student_has_department_student1`
    FOREIGN KEY (`student_sid` , `student_sname`)
    REFERENCES `inha_db`.`student` (`sid` , `sname`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_student_has_department_department1`
    FOREIGN KEY (`department_did` , `department_dname`)
    REFERENCES `inha_db`.`department` (`did` , `dname`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;

INSERT INTO `inha_db`.`building` (`bid`, `bname`) VALUES
(1, 'Building A'),
(2, 'Building B'),
(3, 'Building C'),
(4, 'Building D'),
(5, 'Building E');

INSERT INTO `inha_db`.`room` (`rid`, `rname`, `capacity`, `building_bid`, `building_bname`) VALUES
(101, 'Room 101', 30, 1, 'Building A'),
(102, 'Room 102', 25, 1, 'Building A'),
(201, 'Room 201', 40, 2, 'Building B'),
(202, 'Room 202', 35, 2, 'Building B'),
(301, 'Room 301', 20, 3, 'Building C');

INSERT INTO `inha_db`.`department` (`did`, `dname`, `demail`, `dphonenumber`, `room_rid`, `room_rname`, `room_building_bid`, `room_building_bname`) VALUES
(1, 'Department of Math', 'math@example.com', 1234567890, 101, 'Room 101', 1, 'Building A'),
(2, 'Department of Physics', 'physics@example.com', NULL, 201, 'Room 201', 2, 'Building B'),
(3, 'Department of Chemistry', 'chemistry@example.com', 76543210, 301, 'Room 301', 3, 'Building C'),
(4, 'Department of Computer Science', 'cs@example.com', 5555555, 102, 'Room 102', 1, 'Building A'),
(5, 'Department of Biology', 'biology@example.com', NULL, 202, 'Room 202', 2, 'Building B');

INSERT INTO `inha_db`.`student` (`sid`, `sname`, `semail`, `sphonenumber`, `Major`) VALUES
(1219, 'Joon', 'joon@example.com', '123-456-7890', 'Computer Science'),
(2222, 'Alice Smith', 'alice@example.com', '987-654-3210', 'Mathematics'),
(3333, 'Bob Johnson', NULL, '555-555-5555', 'Physics'),
(4444, 'Eva Brown', 'eva@example.com', NULL, 'Biology'),
(5555, 'David Lee', 'david@example.com', '111-111-1111', 'Chemistry');

INSERT INTO `inha_db`.`student_has_department` (`student_sid`,`student_sname`, `department_did`, `department_dname`) VALUES
(1219, 'Joon', 1, 'Department of Computer Science'),
(2222, 'Alice Smith',1, 'Department of Computer Science'),
(2222, 'Alice Smith',2, 'Department of Physics'),
(3333, 'Bob Johnson',3, 'Department of Chemistry'),
(4444, 'Eva Brown',5, 'Department of Biology'),
(5555, 'David Lee',4, 'Department of Computer Science');



SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
