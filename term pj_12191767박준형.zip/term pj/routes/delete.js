import express from 'express';
import { selectSql, deleteSql } from '../database/sql';

const router = express.Router();

router.get('/', async (req, res) => {
    if (req.session.user && req.session.user.type === 'admin') {
        const doctors = await selectSql.getDoctor();
        const nurses = await selectSql.getNurse();
        const patients = await selectSql.getPatient();

        res.render('delete', {
            title: 'Delete',
            Doctors: doctors,
            Nurses: nurses,
            Patients: patients,
        });
    } else {
        res.redirect('/');
    }
});

router.post('/', async (req, res) => {
    if (req.session.user && req.session.user.type === 'admin') {
        await deleteSql.deleteDoctor(req.body.doctorId);
        await deleteSql.deleteNurse(req.body.nurseId);
        await deleteSql.deletePatient(req.body.patientId);
        res.redirect('/delete');
    } else {
        res.redirect('/');
    }
});

export default router;
