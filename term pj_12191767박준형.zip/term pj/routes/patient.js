import express from 'express';
import { selectSql, insertSql, deleteSql } from '../database/sql';

const router = express.Router();

// 로그인 검증
router.use((req, res, next) => {
    if (req.session.user && req.session.user.type === 'patient') {
        next();
    } else {
        res.status(403).send('Unauthorized');
    }
});

// RESERVATION 정보 조회
router.get('/', async (req, res) => {
    if (req.session.user && req.session.user.type === 'patient') {
        const reservations = await selectSql.getReservationById([req.session.user.id]);
        res.render('patient', { reservations });
    } else {
        res.status(403).send('Unauthorized');
    }
});
// RESERVATION 정보 삽입 (예약)
router.post('/reservations', async (req, res) => {
    const { reservationNumber, dateTime, departmentId } = req.body;
    const patientID = req.session.user.id;  // 로그인한 사용자의 id를 가져옵니다.
    const sql = `INSERT INTO reservation (Reservation_Number, Reservation_DateTime, Department_ID, Patient_ID) VALUES (?, ?, ?, ?)`;
    await insertSql.addReservation(sql, [reservationNumber, dateTime, departmentId, patientID]);  // 수정된 부분
    res.redirect('/patient');
});

// RESERVATION 정보 삭제 (예약 취소)
router.post('/reservations/delete', async (req, res) => {
    const { reservationNumber } = req.body;
    const sql = `DELETE FROM reservation WHERE Reservation_Number = ? AND Patient_ID = ?`;
    await deleteSql.deleteReservation(sql, [reservationNumber, req.session.user.id]);  
    res.redirect('/patient');
});


export default router;
