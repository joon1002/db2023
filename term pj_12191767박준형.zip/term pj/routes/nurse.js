import express from 'express';
import { selectSql, insertSql, updateSql, deleteSql } from '../database/sql';

const router = express.Router();

// 로그인 검증
router.use((req, res, next) => {
    if (req.session.user && req.session.user.type === 'nurse') {
        next();
    } else {
        res.status(403).send('Unauthorized');
    }
});

// TREATMENT 정보 조회
router.get('/', async (req, res) => {
    if (req.session.user && req.session.user.type === 'nurse') {
        const treatments = await selectSql.getTreatment([req.session.user.id]);
       // console.log(treatments);  // 검사용 코드(터미널에서 정보 잘 받았는지 확인)
        res.render('nurse', { treatments });
    } else {
        res.status(403).send('Unauthorized');
    }
});
// TREATMENT 정보 삭제
router.post('/treatments/delete', async (req, res) => {
    const { treatment_id } = req.body; 
    const sql = `DELETE FROM treatment WHERE treatment_id = ?`;  
    try {
        const result = await deleteSql.deleteNurse(sql, [treatment_id]);  
        console.log('Treatment deleted successfully.');
    } catch (err) {
        console.error(err);
    }
    res.redirect('/nurse');
});

// TREATMENT 정보 입력
router.post('/treatments', async (req, res) => {
    const { dateTime, details, patientId } = req.body;
    const sql = `INSERT INTO treatment (Treatment_DateTime, Treatment_Details, Nurse_ID, Patient_ID) VALUES (?, ?, ?, ?)`;
    await insertSql.addNurse(sql, [dateTime, details, req.session.user.id, patientId]);
    res.redirect('/nurse');
});

// TREATMENT 정보 수정
router.post('/treatments/update', async (req, res) => {
    const { dateTime, details, patientId } = req.body;
    const sql = `UPDATE treatment SET Treatment_DateTime = ?, Treatment_Details = ? WHERE Nurse_ID = ? AND Patient_ID = ?`;
    await updateSql.updateNurse(sql, [dateTime, details, req.session.user.id, patientId]);
    res.redirect('/nurse');
});



export default router;
