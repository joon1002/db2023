import express from "express";
import { selectSql } from "../database/sql";

const router = express.Router();

router.get('/', (req, res) => {
    res.render('login');
});

router.post('/', async (req, res) => {
    const vars = req.body;

    if (!vars.id || !vars.password) {
        console.log('Invalid input. Please provide both ID and password.');
        res.send('<script>alert("Invalid input. Please provide both ID and password."); location.href="/";</script>');
        return;
    }

    const admins = await selectSql.getAdmin();
    const doctors = await selectSql.getDoctor();
    const nurses = await selectSql.getNurse();
    const patients = await selectSql.getPatient();

    const admin = admins.find(admin => admin.Admin_ID === vars.id && admin.password === vars.password);
    const doctor = doctors.find(doctor => doctor.Doctor_ID === parseInt(vars.id) && doctor.Password === vars.password);
    const nurse = nurses.find(nurse => nurse.Nurse_ID === parseInt(vars.id) && nurse.Password === vars.password);
    const patient = patients.find(patient => patient.Patient_ID === parseInt(vars.id) && patient.Password === vars.password);

    if (admin || (vars.id === 'admin' && vars.password === 'admin123')) {
        console.log('관리자 로그인 성공!');
        req.session.user = { id: vars.id, type: 'admin', checkLogin: true };
        res.redirect('/admin');
    } else if (doctor) {
        console.log('의사 로그인 성공!');
        req.session.user = { id: doctor.Doctor_ID, type: 'doctor', checkLogin: true };
        res.redirect('/doctor');
    } else if (nurse) {
        console.log('간호사 로그인 성공!');
        req.session.user = { id: nurse.Nurse_ID, type: 'nurse', checkLogin: true };
        res.redirect('/nurse');
    } else if (patient) {
        console.log('환자 로그인 성공!');
        req.session.user = { id: patient.Patient_ID, type: 'patient', checkLogin: true };
        res.redirect('/patient');
    } else {
        console.log('로그인 실패.');
        res.send('<script>alert("Login failed. Please check your ID and password."); location.href="/";</script>');
    }
});

export default router;
