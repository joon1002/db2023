import express from 'express';
import { selectSql } from '../database/sql';

const router = express.Router();

router.get('/', async (req, res) => {
    if (req.session.user) {
        const admins = await selectSql.getAdmin();
        const doctors = await selectSql.getDoctor();
        const nurses = await selectSql.getNurse();
        const patients = await selectSql.getPatient();

        res.render('select', {
            main_title: "Tables in HospitalDB",
            title1: "Admins",
            title2: "Doctors",
            title3: "Nurses",
            title4: "Patients",
            Admins: admins,
            Doctors: doctors,
            Nurses: nurses,
            Patients: patients,
        });
    } else {
        res.redirect('/');
    }
})

export default router;
