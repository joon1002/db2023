import express from 'express';
import { selectSql, insertSql, deleteSql, updateSql } from '../database/sql';

const router = express.Router();

router.get('/', async (req, res) => {
    if (req.session.user && req.session.user.type === 'admin') {
        const doctors = await selectSql.getDoctor();
        const nurses = await selectSql.getNurse();
        res.render('admin', { doctors: doctors, nurses: nurses });
    } else {
        res.status(403).send('Unauthorized');
    }
});

//Doctor 정보 삽입
router.post('/doctor', async (req, res) => {
    const { doctorName, doctorId, departmentId, address, phoneNumber, password } = req.body;
    const sql = "INSERT INTO doctor (Doctor_ID, Department_ID, Name, Address, Phone_Number, Password) VALUES (?, ?, ?, ?, ?, ?)";
    try {
        const result = await insertSql.addDoctor(sql, [doctorId, departmentId, doctorName, address, phoneNumber, password]);
        console.log('Doctor added successfully.');
    } catch (err) {
        console.error(err);
    }
    res.redirect('/admin');
});
//Nurse 정보 삽입
router.post('/nurse', async (req, res) => {
    const { nurseName, nurseId, departmentId, address, phoneNumber, password } = req.body;
    const sql = "INSERT INTO nurse (Nurse_ID, Department_ID, Name, Address, Phone_Number, Password) VALUES (?, ?, ?, ?, ?, ?)";
    try {
        const result = await insertSql.addNurse(sql, [nurseId, departmentId, nurseName, address, phoneNumber, password]);
        console.log('Nurse added successfully.');
    } catch (err) {
        console.error(err);
    }
    res.redirect('/admin');
});

// DOCTOR 정보 삭제
router.post('/doctor/delete', async (req, res) => {
    const { doctorId } = req.body;
    const sql = "DELETE FROM doctor WHERE Doctor_ID = ?";
    try {
        const result = await deleteSql.deleteDoctor(sql, [doctorId]);
        console.log('Doctor deleted successfully.');
    } catch (err) {
        console.error(err);
    }
    res.redirect('/admin');
});

// DOCTOR 정보 수정
router.post('/doctor/update', async (req, res) => {
    const { doctorId, newDoctorName, newDepartmentId, newAddress, newPhoneNumber, newPassword } = req.body;
    const sql = "UPDATE doctor SET Name = ?, Department_ID = ?, Address = ?, Phone_Number = ?, Password = ? WHERE Doctor_ID = ?";
    try {
        const result = await updateSql.updateDoctor(sql, [newDoctorName, newDepartmentId, newAddress, newPhoneNumber, newPassword, doctorId]);
        console.log('Doctor updated successfully.');
    } catch (err) {
        console.error(err);
    }
    res.redirect('/admin');
});

// NURSE 정보 삭제
router.post('/nurse/delete', async (req, res) => {
    const { nurseId } = req.body;
    const sql = "DELETE FROM nurse WHERE Nurse_ID = ?";
    try {
        const result = await deleteSql.deleteNurse(sql, [nurseId]);
        console.log('Nurse deleted successfully.');
    } catch (err) {
        console.error(err);
    }
    res.redirect('/admin');
});

// NURSE 정보 수정
router.post('/nurse/update', async (req, res) => {
    const { nurseId, newNurseName, newDepartmentId, newAddress, newPhoneNumber, newPassword } = req.body;
    const sql = "UPDATE nurse SET Name = ?, Department_ID = ?, Address = ?, Phone_Number = ?, Password = ? WHERE Nurse_ID = ?";
    try {
        const result = await updateSql.updateNurse(sql, [newNurseName, newDepartmentId, newAddress, newPhoneNumber, newPassword, nurseId]);
        console.log('Nurse updated successfully.');
    } catch (err) {
        console.error(err);
    }
    res.redirect('/admin');
});

export default router;
