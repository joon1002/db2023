import express from 'express';
import { selectSql, insertSql, deleteSql, updateSql } from '../database/sql';

const router = express.Router();

// 로그인 검증
router.use((req, res, next) => {
    if (req.session.user && req.session.user.type === 'doctor') {
        next();
    } else {
        res.status(403).send('Unauthorized');
    }
});

// EXAMINATION 정보 조회
router.get('/', async (req, res) => {
    if (req.session.user && req.session.user.type === 'doctor') {
        const examinations = await selectSql.getExaminations([req.session.user.id]);
        res.render('doctor', { examinations });
    } else {
        res.status(403).send('Unauthorized');
    }
});

// EXAMINATION 정보 삭제
router.post('/examinations/delete', async (req, res) => {
    const { examination_id } = req.body;
    const sql = `DELETE FROM examination WHERE examination_id = ?`;
    try {
        const result = await deleteSql.deleteDoctor(sql, [examination_id]);
        console.log('Examination deleted successfully.');
    } catch (err) {
        console.error(err);
    }
    res.redirect('/doctor');
});



// EXAMINATION 정보 입력
router.post('/examinations', async (req, res) => {
    const { dateTime, details, patientId } = req.body;
    const sql = `INSERT INTO examination (Examination_DateTime, Examination_Details, Doctor_ID, Patient_ID) VALUES (?, ?, ?, ?)`;
    await insertSql.addDoctor(sql, [dateTime, details, req.session.user.id, patientId]);
    res.redirect('/doctor');
});

// EXAMINATION 정보 수정
router.post('/examinations/update', async (req, res) => {
    const { dateTime, details, patientId } = req.body;
    const sql = `UPDATE examination SET Examination_DateTime = ?, Examination_Details = ? WHERE Doctor_ID = ? AND Patient_ID = ?`;
    await updateSql.updateDoctor(sql, [dateTime, details, req.session.user.id, patientId]);
    res.redirect('/doctor');
});


export default router;
