import express from 'express';
import { selectSql } from '../database/sql';

const router = express.Router();

router.get('/', async (req, res) => {
    try {
        const patientId = req.query.search;
        const patient = await selectSql.getPatientById([patientId]);
        
        if (patient.length > 0) {
            res.render('search', { patient: patient[0] });
        } else {
            res.render('search', { error: '정보가 없는 환자' });
        }
    } catch (error) {
        console.error(error);
        res.render('search', { error: '환자 조회 에러' });
    }
});
router.post('/', async (req, res) => {
    try {
        const patientId = req.body.search; // form에서 POST로 전달된 데이터를 받습니다.
        const patient = await selectSql.getPatientById([patientId]);
        
        if (patient.length > 0) {
            res.render('search', { patient: patient[0] });
        } else {
            res.render('search', { error: '정보가 없는 환자' });
        }
    } catch (error) {
        console.error(error);
        res.render('search', { error: '환자 조회 에러' });
    }
});


export default router;
