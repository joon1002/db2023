import mysql from 'mysql2';

require("dotenv").config();

const pool = mysql.createPool({
    host: 'localhost',
    port: 3306,
    user: 'root',
    password: 'happy99',
    database: 'hospital',
});

const promisePool = pool.promise();

// select query
export const selectSql = {
    getAdmin: async () => {
        const sql = `select * from admin_view`;
        const [result] = await promisePool.query(sql);
        return result;
    },
    getDoctor: async () => {
        const sql = `select * from doctor`;
        const [result] = await promisePool.query(sql);
        return result;
    },
    getNurse: async () => {
        const sql = `select * from nurse`;
        const [result] = await promisePool.query(sql);
        return result;
    },
    getPatient: async () => {
        const sql = `select * from patient`;
        const [result] = await promisePool.query(sql);
        return result;
    },
    getExaminations: async (params) => {
        const sql = `SELECT * FROM examination WHERE Doctor_ID = ?`;
        const [result] = await promisePool.query(sql, params);
        return result;
    },
    getTreatment: async (params) => {
        const sql = `SELECT * FROM treatment WHERE Nurse_ID = ?`;
        const [result] = await promisePool.query(sql, params);
        return result;
    },
    getPatientById: async (params) => {
        const sql = `SELECT * FROM patient WHERE Patient_ID = ?`;
        const [result] = await promisePool.query(sql, params);
        return result;
    },
    getReservationById: async (params) => {
        const sql = `SELECT * FROM reservation WHERE Patient_ID = ?`;
        const [result] = await promisePool.query(sql, params);
        return result;
    },
}


// insert query
export const insertSql = {
    addDoctor: async (sql, params) => {
        const [result] = await promisePool.query(sql, params);
        return result;
    },
    addNurse: async (sql, params) => {
        const [result] = await promisePool.query(sql, params);
        return result;
    },
    addExamination: async (sql, params) => {
        const [result] = await promisePool.query(sql, params);
        return result;
    },
    addTreatment: async (sql,params) => {
        const [result] = await promisePool.query(sql, params);
        return result;
    },
    addReservation: async (sql,params) => {
        const [result] = await promisePool.query(sql, params);
        return result;
    },
}


// update query
export const updateSql = {
    updateDoctor: async (sql, params) => {
        const [result] = await promisePool.query(sql, params);
        return result;
    },
    updateNurse: async (sql, params) => {
        const [result] = await promisePool.query(sql, params);
        return result;
    },
    updateExamination: async (sql, params) => {
        const [result] = await promisePool.query(sql, params);
        return result;
    },
    updateTreatment: async (sql,params) => {
        const [result] = await promisePool.query(sql, params);
        return result;
    },
    updateReservation: async (sql,params) => {
        const [result] = await promisePool.query(sql, params);
        return result;
    },
}

// delete query
export const deleteSql = {
    deleteDoctor: async (sql, params) => {
        const [result] = await promisePool.query(sql, params);
        return result;
    },
    deleteNurse: async (sql, params) => {
        const [result] = await promisePool.query(sql, params);
        return result;
    },
    deleteExamination: async (sql, params) => {
        const [result] = await promisePool.query(sql, params);
        return result;
    },
    deleteTreatment: async (sql, params) => {
        const [result] = await promisePool.query(sql, params);
        return result;
    },
    deleteReservation: async (sql,params) => {
        const [result] = await promisePool.query(sql, params);
        return result;
    },
}
