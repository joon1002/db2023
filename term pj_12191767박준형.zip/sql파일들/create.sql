-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
-- -----------------------------------------------------
-- Schema hospital
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema hospital
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `hospital` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci ;
USE `hospital` ;

-- -----------------------------------------------------
-- Table `hospital`.`medical_specialty`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `hospital`.`medical_specialty` (
  `Department_ID` INT NOT NULL,
  `Department_Name` VARCHAR(100) NULL DEFAULT NULL,
  `Phone_Number` VARCHAR(15) NULL DEFAULT NULL,
  PRIMARY KEY (`Department_ID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `hospital`.`doctor`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `hospital`.`doctor` (
  `Doctor_ID` INT NOT NULL,
  `Department_ID` INT NULL DEFAULT NULL,
  `Name` VARCHAR(100) NULL DEFAULT NULL,
  `Address` VARCHAR(255) NULL DEFAULT NULL,
  `Phone_Number` VARCHAR(15) NULL DEFAULT NULL,
  `Password` VARCHAR(255) NULL DEFAULT NULL,
  PRIMARY KEY (`Doctor_ID`),
  INDEX `Department_ID` (`Department_ID` ASC) VISIBLE,
  CONSTRAINT `doctor_ibfk_1`
    FOREIGN KEY (`Department_ID`)
    REFERENCES `hospital`.`medical_specialty` (`Department_ID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `hospital`.`nurse`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `hospital`.`nurse` (
  `Nurse_ID` INT NOT NULL,
  `Department_ID` INT NULL DEFAULT NULL,
  `Name` VARCHAR(100) NULL DEFAULT NULL,
  `Address` VARCHAR(255) NULL DEFAULT NULL,
  `Phone_Number` VARCHAR(15) NULL DEFAULT NULL,
  `Password` VARCHAR(255) NULL DEFAULT NULL,
  PRIMARY KEY (`Nurse_ID`),
  INDEX `Department_ID` (`Department_ID` ASC) VISIBLE,
  CONSTRAINT `nurse_ibfk_1`
    FOREIGN KEY (`Department_ID`)
    REFERENCES `hospital`.`medical_specialty` (`Department_ID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `hospital`.`patient`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `hospital`.`patient` (
  `Patient_ID` INT NOT NULL,
  `Doctor_ID` INT NULL DEFAULT NULL,
  `Nurse_ID` INT NULL DEFAULT NULL,
  `Name` VARCHAR(100) NULL DEFAULT NULL,
  `SSN` VARCHAR(11) NULL DEFAULT NULL,
  `Gender` CHAR(1) NULL DEFAULT NULL,
  `Address` VARCHAR(255) NULL DEFAULT NULL,
  `Blood_Type` CHAR(3) NULL DEFAULT NULL,
  `Height` DECIMAL(5,2) NULL DEFAULT NULL,
  `Weight` DECIMAL(5,2) NULL DEFAULT NULL,
  `Phone_Number` VARCHAR(15) NULL DEFAULT NULL,
  `Password` VARCHAR(255) NULL DEFAULT NULL,
  PRIMARY KEY (`Patient_ID`),
  INDEX `Doctor_ID` (`Doctor_ID` ASC) VISIBLE,
  INDEX `Nurse_ID` (`Nurse_ID` ASC) VISIBLE,
  CONSTRAINT `patient_ibfk_1`
    FOREIGN KEY (`Doctor_ID`)
    REFERENCES `hospital`.`doctor` (`Doctor_ID`),
  CONSTRAINT `patient_ibfk_2`
    FOREIGN KEY (`Nurse_ID`)
    REFERENCES `hospital`.`nurse` (`Nurse_ID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `hospital`.`examination`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `hospital`.`examination` (
  `Examination_DateTime` DATETIME NULL DEFAULT NULL,
  `Examination_Details` TEXT NULL DEFAULT NULL,
  `Doctor_ID` INT NULL DEFAULT NULL,
  `Patient_ID` INT NULL DEFAULT NULL,
  INDEX `Doctor_ID` (`Doctor_ID` ASC) VISIBLE,
  INDEX `Patient_ID` (`Patient_ID` ASC) VISIBLE,
  CONSTRAINT `examination_ibfk_1`
    FOREIGN KEY (`Doctor_ID`)
    REFERENCES `hospital`.`doctor` (`Doctor_ID`),
  CONSTRAINT `examination_ibfk_2`
    FOREIGN KEY (`Patient_ID`)
    REFERENCES `hospital`.`patient` (`Patient_ID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `hospital`.`inpatient`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `hospital`.`inpatient` (
  `Patient_ID` INT NOT NULL,
  `Room_Info` VARCHAR(100) NULL DEFAULT NULL,
  `Admission_DateTime` DATETIME NULL DEFAULT NULL,
  `Discharge_DateTime` DATETIME NULL DEFAULT NULL,
  PRIMARY KEY (`Patient_ID`),
  CONSTRAINT `inpatient_ibfk_1`
    FOREIGN KEY (`Patient_ID`)
    REFERENCES `hospital`.`patient` (`Patient_ID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `hospital`.`reservation`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `hospital`.`reservation` (
  `Reservation_Number` INT NOT NULL,
  `Reservation_DateTime` DATETIME NULL DEFAULT NULL,
  `Department_ID` INT NULL DEFAULT NULL,
  `Patient_ID` INT NULL DEFAULT NULL,
  PRIMARY KEY (`Reservation_Number`),
  INDEX `Department_ID` (`Department_ID` ASC) VISIBLE,
  INDEX `Patient_ID` (`Patient_ID` ASC) VISIBLE,
  CONSTRAINT `reservation_ibfk_1`
    FOREIGN KEY (`Department_ID`)
    REFERENCES `hospital`.`medical_specialty` (`Department_ID`),
  CONSTRAINT `reservation_ibfk_2`
    FOREIGN KEY (`Patient_ID`)
    REFERENCES `hospital`.`patient` (`Patient_ID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


-- -----------------------------------------------------
-- Table `hospital`.`treatment`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `hospital`.`treatment` (
  `Treatment_DateTime` DATETIME NULL DEFAULT NULL,
  `Treatment_Details` TEXT NULL DEFAULT NULL,
  `Nurse_ID` INT NULL DEFAULT NULL,
  `Patient_ID` INT NULL DEFAULT NULL,
  INDEX `Nurse_ID` (`Nurse_ID` ASC) VISIBLE,
  INDEX `Patient_ID` (`Patient_ID` ASC) VISIBLE,
  CONSTRAINT `treatment_ibfk_1`
    FOREIGN KEY (`Nurse_ID`)
    REFERENCES `hospital`.`nurse` (`Nurse_ID`),
  CONSTRAINT `treatment_ibfk_2`
    FOREIGN KEY (`Patient_ID`)
    REFERENCES `hospital`.`patient` (`Patient_ID`))
ENGINE = InnoDB
DEFAULT CHARACTER SET = utf8mb4
COLLATE = utf8mb4_0900_ai_ci;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
