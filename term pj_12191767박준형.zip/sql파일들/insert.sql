start transaction;
-- Insert data into medical_specialty table
INSERT INTO hospital.medical_specialty (Department_ID, Department_Name, Phone_Number)
VALUES
  (1, 'Cardiology', '123-456-7890'),
  (2, 'Orthopedics', '987-654-3210'),
  (3, 'Neurology', '111-222-3333');

-- Insert data into doctor table
INSERT INTO hospital.doctor (Doctor_ID, Department_ID, Name, Address, Phone_Number, Password)
VALUES
  (1101, 1, 'Dr. Smith', '123 Main St', '555-1234', 'password123'),
  (1102, 2, 'Dr. Johnson', '456 Oak St', '555-5678', 'securepass'),
  (1103, 3, 'Dr. White', '789 Pine St', '555-4321', 'safepassword');
-- 여기까지 모드 쿼리 성공하면 트랜잭션 커밋
commit; 

START TRANSACTION;
-- Insert data into nurse table
INSERT INTO hospital.nurse (Nurse_ID, Department_ID, Name, Address, Phone_Number, Password)
VALUES
  (2201, 1, 'Nurse Adams', '123 Elm St', '555-7890', 'nursepass'),
  (2202, 2, 'Nurse Davis', '456 Birch St', '555-2345', 'securenurse'),
  (2203, 3, 'Nurse Lee', '789 Cedar St', '555-6789', 'nurse123');

-- Insert data into patient table
INSERT INTO hospital.patient (Patient_ID, Doctor_ID, Nurse_ID, Name, SSN, Gender, Address, Blood_Type, Height, Weight, Phone_Number, Password)
VALUES
  (3301, 1101, 2201, 'John Doe', '123-45-6789', 'M', '321 Oak St', 'A+', 175.5, 70.2, '555-1111', 'patientpass'),
  (3302, 1102, 2202, 'Jane Smith', '987-65-4321', 'F', '654 Maple St', 'B-', 160.3, 55.8, '555-2222', 'securepatient'),
  (3303, 1103, 2203, 'Bob Johnson', '234-56-7890', 'M', '987 Pine St', 'AB+', 180.1, 80.5, '555-3333', 'patient123');
COMMIT;
START TRANSACTION;
-- Insert data into examination table
INSERT INTO hospital.examination (Examination_DateTime, Examination_Details, Doctor_ID, Patient_ID)
VALUES
  ('2023-11-01 09:00:00', 'General checkup', 1101, 3301),
  ('2023-11-02 10:30:00', 'X-ray scan', 1102, 3302),
  ('2023-11-03 13:45:00', 'MRI scan', 1103, 3303);

-- Insert data into inpatient table
INSERT INTO hospital.inpatient (Patient_ID, Room_Info, Admission_DateTime, Discharge_DateTime)
VALUES
  (3301, 'Room 101', '2023-11-01 09:30:00', '2023-11-03 14:00:00'),
  (3302, 'Room 202', '2023-11-02 11:00:00', '2023-11-04 15:30:00'),
  (3303, 'Room 303', '2023-11-03 14:30:00', '2023-11-05 10:45:00');
COMMIT;
START TRANSACTION;
-- Insert data into reservation table
INSERT INTO hospital.reservation (Reservation_Number, Reservation_DateTime, Department_ID, Patient_ID)
VALUES
  (1, '2023-11-05 10:00:00', 1, 3301),
  (2, '2023-11-06 11:15:00', 2, 3302),
  (3, '2023-11-07 13:30:00', 3, 3303);

-- Insert data into treatment table
INSERT INTO hospital.treatment (Treatment_DateTime, Treatment_Details, Nurse_ID, Patient_ID)
VALUES
  ('2023-11-01 10:00:00', 'Administer medication', 2201, 3301),
  ('2023-11-02 12:30:00', 'Physical therapy', 2202, 3302),
  ('2023-11-03 14:45:00', 'Wound dressing', 2203, 3303);
  
  COMMIT;


