
-- 환자에 관한 인덱스 생성
CREATE INDEX idx_patient_id
ON Patient (Patient_ID);

-- 의사 관한 인덱스 생성 
CREATE INDEX idx_doctor_id
ON Doctor (Doctor_ID);

-- 간호사 관한 인덱스 생성
CREATE INDEX idx_nurse_id 
ON Nurse (Nurse_ID);

