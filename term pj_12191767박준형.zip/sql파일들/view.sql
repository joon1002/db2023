-- 관리자 페이지용 뷰
CREATE VIEW admin_view AS
SELECT Doctor_ID as ID, 'Doctor' as Role, Name, Department_ID, Address, Phone_Number
FROM Doctor
UNION
SELECT Nurse_ID as ID, 'Nurse' as Role, Name, Department_ID, Address, Phone_Number
FROM Nurse;


-- 직원 페이지용 뷰 의사/간호사
CREATE VIEW doctor_view AS
SELECT Doctor.Doctor_ID, Doctor.Name, Doctor.Department_ID, EXAMINATION.EXAMINATION_DETAILS
FROM Doctor
JOIN EXAMINATION ON Doctor.Doctor_ID = EXAMINATION.Doctor_ID;

CREATE VIEW nurse_view AS
SELECT Nurse.Nurse_ID, Nurse.Name, Nurse.Department_ID, TREATMENT.TREATMENT_DETAILS
FROM Nurse
JOIN TREATMENT ON Nurse.Nurse_ID = TREATMENT.Nurse_ID;


-- 환자 페이지용 뷰
CREATE VIEW patient_view AS
SELECT Patient.Patient_ID, Patient.Name, Reservation.Reservation_Number as Reservation_ID, Reservation.Reservation_DateTime as Reservation_Date, Reservation.Department_ID as Doctor_ID
FROM Patient
JOIN Reservation ON Patient.Patient_ID = Reservation.Patient_ID;
