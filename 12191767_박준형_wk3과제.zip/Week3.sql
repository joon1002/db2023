-- 1.Corporate branch에 해당하는 모든 사원의 이름, 기존 급여, 10% 증가된 급여 --
SELECT e.first_name AS 'first_name',
		e.last_name AS 'last_name',
       e.salary AS 'salary',
       e.salary * 1.10 AS 'increased_salary'
FROM employee e
INNER JOIN branch b ON e.branch_id = b.branch_id
WHERE b.branch_name = 'Corporate';

-- 2.급여가 60,000에서 80,000 사이에 있는 모든 남자 사원의 이름, 급여 --
SELECT first_name AS 'first_name',
		last_name AS 'last_name',
       salary AS 'salary'
FROM employee
WHERE sex = 'M' AND salary BETWEEN 60000 AND 80000;

-- 3.모든 사원을 branch_id(내림차순)와 급여(오름차순)로 정렬하고, 이름, branch_id, 급여를 출력 --
SELECT first_name AS 'first_name',
		last_name AS 'last_name',
       branch_id AS 'branch_id',
       salary AS 'salary'
FROM employee
ORDER BY branch_id DESC, salary ASC;

-- 4.'FedEx'와 일하는 급여가 60,000 이상인 모든 사원의 이름, total_sales--
SELECT e.first_name AS 'first_name',
		e.last_name AS 'last_name',
       w.total_sales AS 'total_sales'
FROM employee e
INNER JOIN works_with w ON e.emp_id = w.emp_id
INNER JOIN client c ON w.client_id = c.client_id
WHERE c.client_name = 'FedEx' AND e.salary >= 60000;

-- 사원의 급여의 합, 최고 급여, 최저 급여, 평균 급여 --
SELECT SUM(salary) AS 'total_salary',
       MAX(salary) AS 'max_salary',
       MIN(salary) AS 'min_salary',
       AVG(salary) AS 'avg_salary'
FROM employee;

-- 회사의 총 사원수 --
SELECT COUNT(*) AS 'total_employees' FROM employee;

-- 각 branch별 근무하는 사원의 수를 검색하여 branch 이름과 소속 사원수 출력 ok
SELECT b.branch_name AS 'branch_name',
       COUNT(*) AS 'employees_in_branch'
FROM employee e
INNER JOIN branch b ON e.branch_id = b.branch_id
GROUP BY b.branch_name;
